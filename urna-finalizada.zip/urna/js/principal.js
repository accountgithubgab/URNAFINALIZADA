var inputFirst = document.getElementById('first');
var inputSecond = document.getElementById('second');
var img = document.querySelector('.img-borda img');
var inputNome = document.getElementById('nome');
var inputParido = document.getElementById('partido');
var inputParido1 = document.getElementById('partido1');
var inputTipo = document.getElementById('tipos');
if (document.getElementById("confirma")) {
    document.getElementById("confirma").disabled = true;
}

var votos = JSON.parse(localStorage.getItem('list_votos')) || [];

////////// TABELA
function ContarTodos() {
    JSON.parse(localStorage.getItem('list_votos')).forEach(function (voto) {
        document.getElementById(voto).innerHTML = ContarVotos(voto);
    });
}

function ContarVotos(numeroCandidato) {
    var count = 0;
    JSON.parse(localStorage.getItem('list_votos')).forEach(function (voto) {
        if (voto == numeroCandidato) {
            count++
        }
    });
    return count;
}
////// LOGIN
function Login() {
    var done = 0;
    var username = document.login.username.value;
    username = username.toLowerCase();
    var password = document.login.password.value;
    password = password.toLowerCase();
    if (username == "bryanurna" && password == "ptpsdb") {
        window.location = "./resultado.html";
        done = 1;
    }
    if (done == 0) {
        alert("Senha ou Usuário inválido.");
    }
}
///// TEMPO
function tempo() {
    setTimeout(function () {
        inputFirst.value = "";
        inputSecond.value = "";
        inputNome.value = "";
        inputParido.value = "";
        inputTipo.value = "";
        inputParido1.value = "";
        img.src = './img/limpa/branco.png';
        document.getElementById("confirma").disabled = false;
        document.getElementById("branco").disabled = false;
        document.getElementById("corrige").disabled = false;
        window.location = './secondary.html';
    }, 1000);
};
/////// BRANCO
function branco() {
    var inputConjunto = "branco";
    inputFirst.value = "";
    inputSecond.value = "";
    inputNome.value = "Voto em Branco";
    inputParido.value = "";
    inputTipo.value = "";
    inputParido1.value = "";
    document.getElementById("confirma").disabled = true;
    document.getElementById("branco").disabled = true;
    document.getElementById("corrige").disabled = true;
    votos.push(inputConjunto);
    console.log(inputConjunto);
    salvar();
    tempo();

}
////// LIMPA
function limpa() {
    inputFirst.value = "";
    inputSecond.value = "";
    inputNome.value = "";
    inputParido.value = "";
    inputParido1.value = "";
    inputTipo.value = "";
    img.src = './img/limpa/branco.png';
    document.getElementById("confirma").disabled = true;
    document.getElementById("first").focus();
}
/////RESETAR
function resetar() {
    localStorage.clear();
}
//// AUTOTAB
function autotab(original, destination) {
    if (original.getAttribute && original.value.length == original.getAttribute("maxlength")) {
        destination.focus();
        if (original == second) {
            document.getElementById("confirma").disabled = false;
            visualizar();
        }
    }
}
//////// JSON
function salvar() {

    localStorage.setItem('list_votos', JSON.stringify(votos));
}
////// CONFIRMA
function confirma() {

    document.getElementById("confirma").disabled = true;
    document.getElementById("branco").disabled = true;
    document.getElementById("corrige").disabled = true;

    var first = inputFirst.value;
    var second = inputSecond.value;
    var inputConjunto = (first + second);

    if (inputConjunto == '00') {
        inputConjunto = 'nulo';
        votos.push(inputConjunto);
    } else {
        votos.push(inputConjunto);
    }

    salvar();
    tempo();
}

//////////// VISUALIZAR
function visualizar() {
    var first = inputFirst.value;
    var second = inputSecond.value;
    var inputConjunto = (first + second);
    switch (inputConjunto) {

        /////// 2B

        case '67':
            img.src = './img/MAD/presidente/tiago.jpeg';
            inputNome.value = 'Tiago do Vale de Oliveira';
            inputParido.value = 'MAD - Movimento Amplo de Direita';
            inputTipo.value = 'Presidente';
            break;

        case '42':
            img.src = './img/PLB/presidente/matheusM.jpeg';
            inputNome.value = 'Matheus Marcos Espindola';
            inputParido.value = 'PLB - Partido Liberal Brasileiro';
            inputTipo.value = 'Presidente';
            break;

        case '69':
            img.src = './img/PBM/presidente/mateusS.jpeg';
            inputNome.value = 'Mateus Salgado Barboza Costa';
            inputParido.value = 'PBM - Partido Brasil Melhor';
            inputTipo.value = 'Presidente';
            break;

        case '24':
            img.src = './img/PJ/presidente/gabrielaT.jpeg';
            inputNome.value = 'Gabriela Thiesen';
            inputParido.value = 'PJ - Partido Justo';
            inputTipo.value = 'Presidente';
            break;

        case '39':
            img.src = './img/PLCJ/presidente/caioG.jpeg';
            inputNome.value = 'Caio Guerra Marba Santos';
            inputParido.value = 'PLCJ - Partido Liberal das Causas Justas';
            inputTipo.value = 'Presidente';
            break;

        case '98':
            img.src = './img/PDM/presidente/isadora.jpeg';
            inputNome.value = 'Isadora Roman da Silva';
            inputParido.value = 'PDM - Partido das Mulheres';
            inputTipo.value = 'Presidente';
            break;

        case '26':
            img.src = './img/MMCB/presidente/vitorM.jpeg';
            inputNome.value = 'Vitor Menezes Grando';
            inputParido.value = 'MMCB - Movimento Moderno da Causa';
            inputParido1.value = 'Brasileira';
            inputTipo.value = 'Presidente';
            break;

        case '87':
            img.src = './img/PCLdB/presidente/gabrielL.jpeg';
            inputNome.value = 'Gabriel de Souza Leal';
            inputParido.value = 'PCLdB - Partido Centro Liberal do Brasil';
            inputTipo.value = 'Presidente';
            break;

        ///////// 2A

        case '37':
            img.src = './img/PSDD/presidente/matheusA.jpg';
            inputNome.value = 'Matheus Almeida';
            inputParido.value = 'PSDD - Partido Social Democrata da';
            inputParido1.value = 'Diversidade';
            inputTipo.value = 'Presidente';
            break;

        case '66':
            img.src = './img/PCA/presidente/lucasO.jpg';
            inputNome.value = 'Lucas de Oliveira';
            inputParido.value = 'PCA - Partido Cripto Anarquista';
            inputTipo.value = 'Presidente';
            break;

        case '49':
            img.src = './img/PRD/presidente/camila.jpg';
            inputNome.value = 'Camilia Kirch';
            inputParido.value = 'PRD - Partido da Renovação Democrática';
            inputTipo.value = 'Presidente';
            break;

        case '57':
            img.src = './img/PDL/presidente/ricardo.jpg';
            inputNome.value = 'Ricardo';
            inputParido.value = 'PDL - Partido Democrático Liberal';
            inputTipo.value = 'Presidente';
            break;

        case '97':
            img.src = './img/FNB/presidente/jefferson.jpg';
            inputNome.value = 'Jefferson Carradore Filho';
            inputParido.value = 'FNB - Frente Neo Liberal Brasileira';
            inputTipo.value = 'Presidente';
            break;

        case '06':
            img.src = './img/PLIE/presidente/daviL.jpg';
            inputNome.value = 'Davi Lemes';
            inputParido.value = 'PLIE - Partido da Liberdade Individual';
            inputParido1.value = "e Econômica";
            inputTipo.value = 'Presidente';
            break;

        case '88':
            img.src = './img/PRL/presidente/joaoS.jpg';
            inputNome.value = 'João Pedro da Silva Lopes';
            inputParido.value = 'PRL - Partido do Respeito e Liberdade';
            inputTipo.value = 'Presidente';
            break;

        case '00':
            inputNome.value = "Voto Nulo";
            inputParido.value = "";
            inputParido1.value = "";
            inputTipo.value = "";
            break;

        default:
            img.src = './img/limpa/branco.png';
            inputNome.value = 'Candidato inexistente';
            inputParido.value = "";
            inputParido1.value = "";
            inputTipo.value = "";
            document.getElementById("confirma").disabled = true;
            break;
    }
}